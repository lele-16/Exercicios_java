package exemplos;

public class StringJavaUppercase {
	 public static void main(String[] args) {
		  String txt = "Equipe 4";
		  
		  System.out.println(txt.toUpperCase());
		  System.out.println(txt.toLowerCase());
		  
	}
}
