package exemplos;

public class OperadoresLogicos {
	 public static void main(String[]args) {
		  int x = 14;
		  System.out.println( x > 5 && x < 12 ); //Porque 5 � menor que 7 e 7 � menor que 12
	  }
}
