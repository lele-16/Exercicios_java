package exemplos;
import java.util.Scanner;

public class Conta {
public static void main (String[]args) {
	int numero1=0;
	int numero2=0;
	numero1=10;
	numero2=20;
	int soma=numero1+numero2;
	
	System.out.println(soma);
}
}
