package exemplos;

public class ExemploVetor {
	public static void main(String[] args) {
		String[] carro = {"Ford","Nissan","BMW","Volvo","Hyundai"};
		carro[1] = "Ferrari";
		System.out.println(carro.length);
	}
}
