package exemplos;

public class LacoRepeticaoVetor {
	 public static void main(String[] args) {
			String[] carros = {"Volvo","BMW","Ferrari","Nissan"};
			for (int i = 0; i < carros.length; i++) {
				System.out.println(carros[i]);
			}
		}

}
