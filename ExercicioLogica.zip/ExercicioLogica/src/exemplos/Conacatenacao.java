package exemplos;

public class Conacatenacao {
	 public static void main(String[] args) {
			String nome = "Elton";
			String sobreNome = "Aquino";

			/*System.out.println(nome + " " + sobreNome);*/
			System.out.println(nome.concat(" ".concat(sobreNome)));
		}
}
