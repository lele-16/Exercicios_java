package exemplos;
import java.util.Iterator;

public class StringJavaLength {
	public static void main(String[] args) {
		String txt = "Equipe 04";
		System.out.println("A frase acima pouss�: " + txt.length() + " caracteres");//length retorna a quantidade de posi��es entre as aspas duplas
		
		}
}
