package exemplos;

public class OperadoresLogicosNao {
	public static void main(String[] args) {
		int x = 4;
		System.out.println(!( x > 3 && x < 8));
	}
}
