package exemplos;

public class MathJava {
	public static void main(String[] args) {
		//System.out.println(Math.max(5,9)); Compara e mostra o valor maior
		//System.out.println(Math.min(5,9)); Compara e exibi o menor valor
		double x = Math.sqrt(64); //Mostra a raiz quadrada do valor
		int y = (int) x;
		//System.out.println(Math.abs(-3.9)); // Transforma um valor em absolute ( logo, e positivo)
		//System.out.println(Math.random());// Dos valores colocados sa�ra um numero aleat�rio
		int random = (int)( Math.random() * 101);// Faz com que srujam valores de 0 a 100 de forma aleat�ria
		System.out.println(random);
	}
}
