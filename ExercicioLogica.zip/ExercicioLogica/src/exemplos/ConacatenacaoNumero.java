package exemplos;

public class ConacatenacaoNumero {
	public static void main(String[] args) {
		String txt = "10";
		//int numero = 20;
		String numero = "20";
		String resultado = txt + numero;
		System.out.println(resultado);
	}
}
