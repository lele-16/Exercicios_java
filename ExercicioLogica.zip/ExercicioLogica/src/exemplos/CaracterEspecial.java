package exemplos;

public class CaracterEspecial {
	public static void main(String[] args) {
		String txt = "Eu quero \"f�rias\" aaaaaa";
		String txt2 = "caixa d\'�gua";
		String txt3 = "Me da um \\ p�o de queijo ";
		System.out.println(txt3);
		
		
	}
}
