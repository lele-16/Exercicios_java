package exemplos;

public class JavaIndexOf {
	 public static void main(String[] args) {
			String txt = "Jaja equipe 4";
			
			System.out.println(txt.indexOf("4"));//Busca onde inicia a String
		}
}
