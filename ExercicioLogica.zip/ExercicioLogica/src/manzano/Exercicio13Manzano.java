package manzano;

public class Exercicio13Manzano {
	  public static void main(String[] args) {
	        int numero = 1;

	        while (numero < 200) {
	            if (numero % 4 == 0) { // Verifica se o n�mero � divis�vel por 4
	                System.out.println(numero);
	            }
	            numero++;
	        }
	    }
}
