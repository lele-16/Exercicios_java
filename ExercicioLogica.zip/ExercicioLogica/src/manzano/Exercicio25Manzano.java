package manzano;

public class Exercicio25Manzano {
	public static void main(String[] args) {
        for (int contador = 1; contador < 200; contador++) {
            if (contador % 4 == 0) {
                System.out.println(contador);
            }
        }
    }
}
