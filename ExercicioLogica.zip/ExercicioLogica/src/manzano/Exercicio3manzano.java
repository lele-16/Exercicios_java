package manzano;

public class Exercicio3manzano {
	 public static void main(String[] args) {
	        int numero = 0;

	        while (numero <= 20) {
	            if (numero % 2 != 0) { // Verifica se o n�mero � �mpar
	                System.out.println(numero);
	            }
	            numero++;
	        }
	    }
}
