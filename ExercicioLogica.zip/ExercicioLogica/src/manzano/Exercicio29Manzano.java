package manzano;

public class Exercicio29Manzano {
	public static void main(String[] args) {
        int fatorial = 1;

        for (int contador = 1; contador <= 10; contador++) {
            if (contador % 2 != 0) { // Verifica se o n�mero � �mpar
                fatorial *= contador;
            }
        }

        System.out.println("O fatorial dos n�meros �mpares de 1 a 10 �: " + fatorial);
    }
}
