package manzano;

public class Exercicio22Manzano {
	public static void main(String[] args) {
        int soma = 0;

        for (int contador = 1; contador <= 100; contador++) {
            soma += contador;
        }

        System.out.println("O total da soma dos 100 primeiros n�meros �: " + soma);
    }
}
