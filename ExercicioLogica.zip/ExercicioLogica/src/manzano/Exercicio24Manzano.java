package manzano;

public class Exercicio24Manzano {
	 public static void main(String[] args) {
	        for (int contador = 0; contador <= 20; contador++) {
	            if (contador % 2 != 0) {
	                System.out.println(contador);
	            }
	        }
	    }
}
