package manzano;
import java.util.Scanner;

public class Exercicio16Manzano {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int totalValores = 0;
        int somatorio = 0;
        int valor;

        System.out.println("Digite os valores:");

        while (true) {
            valor = sc.nextInt();

            if (valor < 0) {
                break;
            }

            totalValores++;
            somatorio += valor;
        }

        double media = (totalValores > 0) ? (double) somatorio / totalValores : 0;

        System.out.println("Total do somat�rio: " + somatorio);
        System.out.println("M�dia aritm�tica: " + media);
        System.out.println("Total de valores lidos: " + totalValores);
    }
}
