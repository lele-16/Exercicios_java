package manzano;

public class Exercicio5Manzano {
	public static void main(String[] args) {
        int numeroAtual = 1;
        int numeroAnterior = 1;
        
        System.out.println(numeroAnterior); // Primeiro n�mero
        System.out.println(numeroAtual); // Segundo n�mero
        
        int contador = 3; // Come�amos a partir do terceiro numero
        
        while (contador <= 15) {
            int proximoTermo = numeroAtual + numeroAnterior;
            System.out.println(proximoTermo);
            
            numeroAnterior = numeroAtual;
           numeroAtual = proximoTermo;
            
            contador++;
        }
    }
}
