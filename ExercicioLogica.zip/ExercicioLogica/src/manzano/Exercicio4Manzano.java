package manzano;
import java.util.Scanner;

public class Exercicio4Manzano {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Digite o valor da base (B): ");
        int base = scanner.nextInt();
        
        System.out.print("Digite o valor do expoente (E): ");
        int expoente = scanner.nextInt();
        
        int resultado = 1;
        int contador = 1;
        
        while (contador <= expoente) {
            resultado *= base;
            contador++;
        }
        
        System.out.println("O resultado de " + base + "^" + expoente + " �: " + resultado);
        
        scanner.close();
    }
}
