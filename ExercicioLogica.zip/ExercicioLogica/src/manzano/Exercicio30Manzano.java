package manzano;

public class Exercicio30Manzano {

}
