package manzano;


public class Exercicio2Manzano {
	 public static void main(String[] args) {
	        int contador = 1;
	        int soma = 0;

	        while (contador <= 100) {
	            soma += contador;
	            contador++;
	        }

	        System.out.println("A soma dos 100 primeiros n�meros �: " + soma);
	    }
        
}
