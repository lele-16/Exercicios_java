package manzano;

public class Exercicio14Manzano {
	public static void main(String[] args) {
        int numQuadrados = 64;
        long somatorio = 0; // Utilizamos um long para armazenar n�meros grandes

        for (int quadro = 1; quadro <= numQuadrados; quadro++) {
            long graos = (long) Math.pow(2, quadro - 1);
            somatorio += graos;
        }

        System.out.println("O somat�rio do n�mero de gr�os de trigo em um tabuleiro de xadrez �: " + somatorio);
    }
}
