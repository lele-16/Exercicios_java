package manzano;
import java.util.Scanner;

public class Exercicio27Manzano {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o valor da base: ");
        double base = scanner.nextDouble();

        System.out.print("Digite o valor do expoente: ");
        int expoente = scanner.nextInt();

        double resultado = calcularPotencia(base, expoente);
        System.out.println("O resultado da pot�ncia �: " + resultado);

        scanner.close();
    }

    public static double calcularPotencia(double base, int expoente) {
        if (expoente == 0) {
            return 1;
        } else if (expoente > 0) {
            double resultado = base;
            for (int i = 2; i <= expoente; i++) {
                resultado *= base;
            }
            return resultado;
        } else {
            double resultado = 1 / base;
            for (int i = -2; i >= expoente; i--) {
                resultado /= base;
            }
            return resultado;
        }
    }
}
