package manzano;
import java.util.Scanner;

public class Exercicio15Manzano {
	   public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        int quantidadeValores = 15;
	        long somatorio = 0;

	        for (int contador = 1; contador <= quantidadeValores; contador++) {
	            System.out.print("Digite o " + contador + "� valor: ");
	            int valor = scanner.nextInt();
	            long fatorial = calcularFatorial(valor);
	            somatorio += fatorial;
	        }

	        System.out.println("O somat�rio da fatorial de cada valor lido �: " + somatorio);
	    }

	    public static long calcularFatorial(int valor) {
	        long fatorial = 1;

	        for (int contador = 1; contador <= valor; contador++) {
	            fatorial *= contador;
	        }

	        return fatorial;
	    }
}
