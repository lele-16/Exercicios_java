package manzano;

public class Exercicio21Manzano {
	public static void main(String[] args) {
        for (int contador = 15; contador <= 200; contador++) {
            int quadrado = contador * contador;
            System.out.println("O quadrado de " + contador + " �: " + quadrado);
        }
    }
}
