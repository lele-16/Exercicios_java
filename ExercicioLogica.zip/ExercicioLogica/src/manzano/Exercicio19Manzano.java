package manzano;
import java.util.Scanner;

public class Exercicio19Manzano {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int maiorValor = Integer.MIN_VALUE;
        int menorValor = Integer.MAX_VALUE;

        System.out.println("Digite valores inteiros e positivos:");

        while (true) {
            System.out.print("Digite um valor: ");
            int valor = scanner.nextInt();

            if (valor < 0) {
                break;
            }

            if (valor > maiorValor) {
                maiorValor = valor;
            }

            if (valor < menorValor) {
                menorValor = valor;
            }
        }

        System.out.println("Maior valor: " + maiorValor);
        System.out.println("Menor valor: " + menorValor);

        scanner.close();
    }

}
