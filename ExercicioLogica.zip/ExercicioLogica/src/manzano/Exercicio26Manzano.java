package manzano;

public class Exercicio26Manzano {
	 public static void main(String[] args) {
	        for (int expoente = 0; expoente <= 15; expoente++) {
	            long resultado = calcularPotenciaDeTres(expoente);
	            System.out.println("3^" + expoente + " = " + resultado);
	        }
	    }

	    public static long calcularPotenciaDeTres(int expoente) {
	        if (expoente == 0) {
	            return 1;
	        } else if (expoente == 1) {
	            return 3;
	        } else {
	            long resultado = 3;
	            for (int contador = 2; contador <= expoente; contador++) {
	                resultado *= 3;
	            }
	            return resultado;
	        }
	    }
}
