package manzano;
import java.util.Scanner;

public class Exercicio20Manzano {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o dividendo: ");
        int dividendo = scanner.nextInt();

        System.out.print("Digite o divisor: ");
        int divisor = scanner.nextInt();

        int quociente = 0;

        while (dividendo >= divisor) {
            dividendo -= divisor;
            quociente++;
        }

        System.out.println("O resultado inteiro da divis�o �: " + quociente);

        scanner.close();
    }
}
