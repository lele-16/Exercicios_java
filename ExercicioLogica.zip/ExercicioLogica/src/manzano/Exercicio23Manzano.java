package manzano;

public class Exercicio23Manzano {
	public static void main(String[] args) {
        int soma = 0;

        for (int contador = 1; contador <= 500; contador++) {
            if (contador % 2 == 0) {
                soma += contador;
            }
        }

        System.out.println("O somat�rio dos valores pares de 1 at� 500 �: " + soma);
    }
}
