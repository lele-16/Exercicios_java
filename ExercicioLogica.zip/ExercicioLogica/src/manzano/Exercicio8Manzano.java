package manzano;

public class Exercicio8Manzano {
	public static void main(String[] args) {
        int numero = 50;
        int soma = 0;
        int contador = 0;

        while (numero <= 70) {
            if (numero % 2 == 0) { // Verifica se o n�mero � par
                soma += numero;
                contador++;
            }
            numero++;
        }

        double media = (double) soma / contador;

        System.out.println("A soma dos valores pares de 50 a 70 �: " + soma);
        System.out.println("A m�dia aritm�tica dos valores pares �: " + media);
    }
}
