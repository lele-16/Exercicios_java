package manzano;
import java.util.Scanner;

public class Exercicio1Manzano {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Digite um n�mero: ");
        int numero = scanner.nextInt();
        
        int contador = 1;
        while (contador <= 10) {
            int resultado = numero * contador;
            System.out.println(numero + " x " + contador + " = " + resultado);
            contador++;
        }
        
        scanner.close();
    }
}
