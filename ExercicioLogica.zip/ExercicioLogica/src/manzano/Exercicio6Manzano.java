package manzano;
import java.util.Scanner;

public class Exercicio6Manzano {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int contador = 1;
        int somatorio = 0;

        while (contador <= 10) {
            System.out.print("Digite o valor " + contador + ": ");
            int numero = scanner.nextInt();
            somatorio += numero;
            contador++;
        }

        double media = somatorio / 10.0;

        System.out.println("O total do somat�rio �: " + somatorio);
        System.out.println("A m�dia aritm�tica dos valores �: " + media);

        scanner.close();
    }
}
