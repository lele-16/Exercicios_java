package manzano;

public class Exercicio11Manzano {
	   public static void main(String[] args) {
	        int numero = 15;

	        do {
	            int quadrado = numero * numero;
	            System.out.println("O quadrado de " + numero + " �: " + quadrado);
	            numero++;
	        } while (numero <= 200);
	    }
}
