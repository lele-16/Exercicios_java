package manzano;
import java.util.Scanner;

public class Exercicio9Manzano {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double areaTotal = 0;
        String resposta = "sim";

        while (resposta.equalsIgnoreCase("sim")) {
            System.out.print("Digite o c�modo: ");
            String nomeComodo = scanner.nextLine();

            System.out.print("Digite a largura do c�modo: ");
            double largura = scanner.nextDouble();

            System.out.print("Digite o comprimento do c�modo: ");
            double comprimento = scanner.nextDouble();

            double areaComodo = largura * comprimento;
            areaTotal += areaComodo;

            System.out.println("A �rea do c�modo " + nomeComodo + " �: " + areaComodo + " metros quadrados.");

            scanner.nextLine(); 

            System.out.print("Deseja calcular outro c�modo? (sim/n�o): ");
            resposta = scanner.nextLine();
        }

        System.out.println("A �rea total da resid�ncia �: " + areaTotal + " metros quadrados.");

        scanner.close();
    }
}
