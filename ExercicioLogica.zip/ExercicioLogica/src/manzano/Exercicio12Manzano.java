package manzano;

public class Exercicio12Manzano {
	public static void main(String[] args) {
        int somatorio = 0;

        for (int numero = 1; numero <= 500; numero++) {
            if (numero % 2 == 0) { // Verifica se o n�mero � par
                somatorio += numero;
            }
        }

        System.out.println("O somat�rio dos valores 1 a 500 �: " + somatorio);
    }
}
