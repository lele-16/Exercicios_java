package manzano;
import java.util.Scanner;
public class Exercicio18Manzano {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double areaTotal = 0;

        System.out.println("C�lculo da �rea Total da Resid�ncia");

        while (true) {
            System.out.print("Nome do c�modo (ou 'NAO' para sair): ");
            String nomeComodo = scanner.nextLine();

            if (nomeComodo.equalsIgnoreCase("NAO")) {
                break;
            }

            System.out.print("Largura do c�modo em metros: ");
            double largura = scanner.nextDouble();

            System.out.print("Comprimento do c�modo em metros: ");
            double comprimento = scanner.nextDouble();

            double areaComodo = largura * comprimento;
            areaTotal += areaComodo;

            System.out.println("A �rea do c�modo " + nomeComodo + " �: " + areaComodo + " metros quadrados.\n");

            scanner.nextLine(); // Limpar o buffer do teclado

            System.out.print("Deseja calcular a �rea de outro c�modo? (sim/n�o): ");
            String resposta = scanner.nextLine();

            if (resposta.equalsIgnoreCase("n�o")) {
                break;
            }
        }

        System.out.println("A �rea total da resid�ncia �: " + areaTotal + " metros quadrados.");

        scanner.close();
    }
}
