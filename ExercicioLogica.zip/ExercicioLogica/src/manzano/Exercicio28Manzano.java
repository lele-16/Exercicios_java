package manzano;

public class Exercicio28Manzano {
	public static void main(String[] args) {
        int numero = 15; 
        
        int primeiroNumero = 1;
        int segundoNumero = 1;
        System.out.print(primeiroNumero + ", " + segundoNumero);
        
        for (int contador = 3; contador <= numero; contador++) {
            int proximoNumero = primeiroNumero + segundoNumero;
            System.out.print(", " + proximoNumero);
            
            primeiroNumero = segundoNumero;
            segundoNumero = proximoNumero;
        }
    }
}
