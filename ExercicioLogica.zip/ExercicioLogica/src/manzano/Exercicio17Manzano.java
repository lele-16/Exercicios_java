package manzano;

public class Exercicio17Manzano {
	 public static void main(String[] args) {
	        int inicio = 1;
	        int fim = 10;
	        long resultado = 1;

	        for (int contador = inicio; contador <= fim; contador++) {
	            if (contador % 2 != 0) { // Verifica se o n�mero � �mpar
	                resultado *= calcularFatorial(contador);
	            }
	        }

	        System.out.println("O resultado do fatorial dos valores �mpares de 1 a 10 �: " + resultado);
	    }

	    public static long calcularFatorial(int numero) {
	        long fatorial = 1;

	        for (int contador = 1; contador <= numero; contador++) {
	            fatorial *= contador;
	        }

	        return fatorial;
	    }
}
