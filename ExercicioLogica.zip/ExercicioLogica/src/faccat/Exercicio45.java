package faccat;

public class Exercicio45 {
	public static void main(String[] args) {
        int numero = 8;

        System.out.println("Tabuada do 8:");

        for (int contador = 1; contador <= 10; contador++) {
            int resultado = numero *contador;
            System.out.println(numero + " x " + contador + " = " + resultado);
        }
    }
}
