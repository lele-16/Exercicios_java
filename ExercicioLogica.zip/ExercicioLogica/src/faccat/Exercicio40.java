package faccat;

public class Exercicio40 {
	  public static void main(String[] args) {
	        for (int contador = 1; contador <= 10; contador++) {
	            System.out.println(contador);
	        }
	    }
}
