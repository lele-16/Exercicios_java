package faccat;

public class Exercicio47 {

}
