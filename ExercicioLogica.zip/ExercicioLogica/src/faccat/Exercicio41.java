package faccat;

public class Exercicio41 {
	public static void main(String[] args) {
        for (int contador = 10; contador >= 1; contador--) {
            System.out.println(contador);
        }
    }
}
